import datetime
from django.db import models
from django.utils import timezone

"""
Django的模型其实指的是数据库的表格以及表格之间的关系
每个模型都被表示为django.db.models.Model类的子类,每个模型有许多类变量,它们都表示模型里的一个数据库字段
每个字段都是Field类的实例,每个 Field 类实例变量的名字（例如 question_text 或 pub_date ）也是字段名
数据库会将它们作为列名
"""
# Create your models here.
# 如果没有修改，生成的数据表的名称将为应用的小写加类的小写，如polls_question
class Question(models.Model):
    # 如果Field类没有指定名称，则Django将自动使用类实例变量的名称作为字段名
    question_text = models.CharField(max_length=200)
    pub_date = models.DateTimeField("date published")

    def __str__(self) -> str:
        return self.question_text
    
    def was_published_recently(self):
        return self.pub_date >= timezone.now() - datetime.timedelta(days=1)


class Choice(models.Model):
    #  ForeignKey 定义了一个关系。这将告诉 Django，每个 Choice 对象都关联到一个 Question 对象。Django 支持所有常用的数据库关系：多对一、多对多和一对一。
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    choice_text = models.CharField(max_length=200)
    votes = models.IntegerField(default=0)

    def __str__(self) -> str:
        return self.choice_text


