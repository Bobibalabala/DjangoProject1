"""
URL configuration for mysite project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include

# include 函数允许应用其他URLconfs，每当遇到一个include()时，他会截断此项匹配的URL的部分，并将剩余的字符串发送到URLconf以供进一步处理
"""
path()具有四个参数，两个必须的参数route和view,两个可选参数kwargs和name。
route:是一个URL的准则，类似正则表达式，当Django响应一个请求的时候，会从urlpatterns的第一项开始，按顺序依次匹配列表中的项，直到招到匹配的项
        这些准则不会匹配GET和POST参数或域名，如处理请求https://www.example.com/myapp/?page=3 ，只会尝试匹配myapp/
view:当Django找到了一个匹配的准则，就会调用这个特定的试图函数，并传入一个HttpRequest对象作为第一个参数，被捕获的参数以关键字参数的形式传入
kwargs:任意个关键字参数可以作为一个字典传递给目标试图函数
name:为这个URL取名，使你在Django的任一地方唯一地应用它，尤其时在模板中，这个有用的特性允许你只修改一个文件就能全局地修改某个url的模式
"""
urlpatterns = [
    path('admin/', admin.site.urls),
    path('polls/', include("polls.urls")),
]
